/** @odoo-module */

const {Component} = owl;

class ReconciliationRainbowManComponent extends Component {}
ReconciliationRainbowManComponent.template = "reconciliation.done";
