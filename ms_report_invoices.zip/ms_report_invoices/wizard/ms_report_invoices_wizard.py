import xlsxwriter
import base64
from odoo import fields, models, api
from io import BytesIO
from datetime import datetime
from pytz import timezone
import pytz
from odoo.exceptions import UserError, ValidationError
selection_field = {'posted': 'Posted Entries only',
                   'draft': 'Include UnPosted Entries'}

class MsReportInvoicesWizard(models.TransientModel):
    _name = "ms.report.invoices.wizard"
    _description = "Invoices Report .xlsx"

    start_date = fields.Date(string="Start Date", required="1",
                             help="Select start date to fetch the trial "
                                  "balance data")
    end_date = fields.Date(string="End Date", required="1",
                           help="Select end date to fetch the trial "
                                "balance data")
    partner_ids = fields.Many2many('res.partner', string="Partners",
                                   domain="[('customer_rank', '>', 0)]",
                                    help="Select the partners to added in the"
                                         "Report Filter")
    journals_ids = fields.Many2many('account.journal', string="Journals",
                                    help="Select the journals to added in the"
                                         "trail balance",
                                    default=[1])
    company_id = fields.Many2one('res.company', string="Company",
                                 help="Select the company of the journals",
                                 default=lambda self: self.env.company)
    state = fields.Selection([
        ('posted', 'Posted Entries only'),
        ('draft', 'Include UnPosted Entries'),
    ], tracking=True, string="State", help="Select the state of journal "
                                           "entries which we want to report",
                                    default='posted')

    @api.model
    def get_default_date_tz(self):
        return pytz.UTC.localize(datetime.now()).astimezone(timezone(self.env.user.tz or 'UTC'))

    datas = fields.Binary('File', readonly=True)
    datas_fname = fields.Char('Filename', readonly=True)


    def print_excel_report(self):
        data = self.read()[0]
        start_date = data['start_date']
#        raise UserWarning(start_date)
        end_date = data['end_date']
        state = data['state']
        where_state = '1=1'
        if state == 'posted':
            where_state = "account_move_line.parent_state = 'posted'"
        partner_ids = data['partner_ids']
        where_partner_ids = '1=1'
        if partner_ids:
            where_partner_ids = "res_partner.id in %s" % str(tuple(partner_ids)).replace(',)', ')')
#        raise UserWarning(where_partner_ids)


        datetime_string = self.get_default_date_tz().strftime("%Y-%m-%d %H:%M:%S")
        date_string = self.get_default_date_tz().strftime("%Y-%m-%d")
        report_name = 'Invoices Report'
        filename = '%s %s' % (report_name, date_string)

        columns = [
            ('No', 5, 'no', 'no'),
            ('Customer', 30, 'char', 'char'),
            ('Invoice', 20, 'char', 'char'),
            ('Invoice Date', 20, 'datetime', 'datetime'),
            ('Product Value', 20, 'float', 'float'),
            ('Vat', 20, 'float', 'float'),
            ('With_holding', 20, 'float', 'float'),
            ('Total invoices', 20, 'float', 'float'),
        ]

        datetime_format = '%Y-%m-%d %H:%M:%S'
        utc = datetime.now().strftime(datetime_format)
        utc = datetime.strptime(utc, datetime_format)
        tz = self.get_default_date_tz().strftime(datetime_format)
        tz = datetime.strptime(tz, datetime_format)
        duration = tz - utc
        hours = duration.seconds / 60 / 60
        if hours > 1 or hours < 1:
            hours = str(hours) + ' hours'
        else:
            hours = str(hours) + ' hour'
        query = """

                    SELECT
                        res_partner.name AS partner,
                        account_move_line.move_name AS invoice,
                        account_move_line.date as inv_date,
                        SUM(account_move_line.credit)	   FILTER (WHERE account_account.code like '500001') AS sales_account,
                        SUM(account_move_line.credit)	   FILTER (WHERE account_account.code like '201017') AS vat_output,
                        SUM(account_move_line.debit)	   FILTER (WHERE account_account.code like '104042') AS with_holding,
        				SUM(account_move_line.debit)	   FILTER (WHERE account_account.code = '102011') AS accounts_receivable
                    FROM
                        account_move_line
                    JOIN
                        account_account ON account_account.id = 
                        account_move_line.account_id
                    JOIN
                        res_partner ON res_partner.id = 
                        account_move_line.partner_id
                    WHERE
                        journal_id=1 and %s  and account_move_line.date >= '%s' and  account_move_line.date <= '%s' and %s
                    GROUP BY
                        partner,
        				invoice,
        				inv_date        
                    ORDER BY 
						partner
					"""
        
        self._cr.execute(query % (where_partner_ids, start_date, end_date,where_state))
        result = self._cr.fetchall()
        
        fp = BytesIO()
        workbook = xlsxwriter.Workbook(fp)
        wbf, workbook = self.add_workbook_format(workbook)

        worksheet = workbook.add_worksheet(report_name)
        worksheet.merge_range('A2:I3', report_name, wbf['title_doc'])

        row = 5

        col = 0
        for column in columns:
            column_name = column[0]
            column_width = column[1]
            worksheet.set_column(col, col, column_width)
            worksheet.write(row-1, col, column_name, wbf['header_orange'])

            col += 1
        
        row += 1
        no = 1

        column_float_number = {}
        if result:
#         raise UserWarning(len(result))
         for res in result:
            col = 0
            for column in columns:
                column_type = column[2]
                if column_type == 'char':
#                    raise UserWarning(col)
                    col_value = res[col-1] if res[col-1] else ''
                    wbf_value = wbf['content']
                elif column_type == 'no':
                    col_value = no
                    wbf_value = wbf['content']
                elif column_type == 'datetime':
#                    col_value = res[col - 1].strftime('%Y-%m-%d %H:%M:%S') if res[col - 1] else ''
                    col_value = res[col - 1].strftime('%Y-%m-%d') if res[col - 1] else ''
                    wbf_value = wbf['content']
                else:
                    col_value = res[col-1] if res[col-1] else 0
                    if column_type == 'float':
                        wbf_value = wbf['content_float']
                    else:  # number
                        wbf_value = wbf['content_number']
                    column_float_number[col] = column_float_number.get(col, 0) + col_value
                if isinstance(col_value, dict):
                    col_value = list(col_value.values())[0]
                worksheet.write(row-1, col, col_value, wbf_value)

                col += 1
            
            row += 1
            no += 1
        else:
             raise UserError("No invoices were issued during this period")
        worksheet.merge_range('A%s:C%s' % (row, row), 'Grand Total', wbf['total_orange'])
        for x in range(len(columns)):
            if x in (0,1):
                continue
            column_type = columns[x][3]
            if column_type == 'char':
                worksheet.write(row-1, x, '', wbf['total_orange'])
            else:
                if column_type == 'float':
                    wbf_value = wbf['total_float_orange']
                else:  # number
                    wbf_value = wbf['total_number_orange']
                if x in column_float_number:
                    worksheet.write(row-1, x, column_float_number[x], wbf_value)
                else:
                    worksheet.write(row-1, x, 0, wbf_value)
        
        worksheet.write('A%s' % (row+2), 'Date %s (%s)' % (
            datetime_string, self.env.user.tz or 'UTC'), wbf['content_datetime'])
        workbook.close()
        out = base64.encodebytes(fp.getvalue())
        self.write({'datas': out, 'datas_fname': filename})
        fp.close()
        filename += '%2Exlsx'

        return {
            'type': 'ir.actions.act_url',
            'target': 'new',
            'url': 'web/content/?model='+self._name+'&id='+str(self.id)+'&field=datas&download=true&filename='+filename,
        }

    def add_workbook_format(self, workbook):
        colors = {
            'white_orange': '#FFFFDB',
            'orange': '#FFC300',
            'red': '#FF0000',
            'yellow': '#F6FA03',
        }

        wbf = {}
        wbf['header'] = workbook.add_format(
            {'bold': 1, 'align': 'center', 'bg_color': '#FFFFDB', 'font_color': '#000000', 'font_name': 'Georgia'})
        wbf['header'].set_border()

        wbf['header_orange'] = workbook.add_format({
            'bold': 1, 'align': 'center', 'bg_color': colors['orange'], 'font_color': '#000000', 'font_name': 'Georgia'})
        wbf['header_orange'].set_border()

        wbf['header_yellow'] = workbook.add_format(
            {'bold': 1, 'align': 'center', 'bg_color': colors['yellow'], 
             'font_color': '#000000', 'font_name': 'Georgia'})
        wbf['header_yellow'].set_border()
        
        wbf['header_no'] = workbook.add_format(
            {'bold': 1, 'align': 'center', 'bg_color': '#FFFFDB', 'font_color': '#000000', 'font_name': 'Georgia'})
        wbf['header_no'].set_border()
        wbf['header_no'].set_align('vcenter')
                
        wbf['footer'] = workbook.add_format({'align': 'left', 'font_name': 'Georgia'})
        
        wbf['content_datetime'] = workbook.add_format({'num_format': 'yyyy-mm-dd hh:mm:ss', 'font_name': 'Georgia'})
        wbf['content_datetime'].set_left()
        wbf['content_datetime'].set_right()
        
        wbf['content_date'] = workbook.add_format({'num_format': 'yyyy-mm-dd', 'font_name': 'Georgia'})
        wbf['content_date'].set_left()
        wbf['content_date'].set_right() 
        
        wbf['title_doc'] = workbook.add_format({
            'bold': True,
            'align': 'center',
            'valign': 'vcenter',
            'font_size': 20,
            'font_name': 'Georgia',
        })
        
        wbf['company'] = workbook.add_format({'align': 'left', 'font_name': 'Georgia'})
        wbf['company'].set_font_size(11)
        
        wbf['content'] = workbook.add_format()
        wbf['content'].set_left()
        wbf['content'].set_right() 
        
        wbf['content_float'] = workbook.add_format({'align': 'right', 'num_format': '#,##0.00', 'font_name': 'Cambria'})
        wbf['content_float'].set_right() 
        wbf['content_float'].set_left()

        wbf['content_number'] = workbook.add_format({'align': 'right', 'num_format': '#,##0', 'font_name': 'Georgia'})
        wbf['content_number'].set_right() 
        wbf['content_number'].set_left() 
        
        wbf['content_percent'] = workbook.add_format({'align': 'right', 'num_format': '0.00%', 'font_name': 'Georgia'})
        wbf['content_percent'].set_right() 
        wbf['content_percent'].set_left() 
                
        wbf['total_float'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['white_orange'], 'align': 'right', 
             'num_format': '#,##0.00', 'font_name': 'Georgia'})
        wbf['total_float'].set_top()
        wbf['total_float'].set_bottom()            
        wbf['total_float'].set_left()
        wbf['total_float'].set_right()         
        
        wbf['total_number'] = workbook.add_format(
            {'align': 'right', 'bg_color': colors['white_orange'], 'bold': 1, 
             'num_format': '#,##0', 'font_name': 'Georgia'})
        wbf['total_number'].set_top()
        wbf['total_number'].set_bottom()            
        wbf['total_number'].set_left()
        wbf['total_number'].set_right()
        
        wbf['total'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['white_orange'], 
             'align': 'center', 'font_name': 'Georgia'})
        wbf['total'].set_left()
        wbf['total'].set_right()
        wbf['total'].set_top()
        wbf['total'].set_bottom()

        wbf['total_float_yellow'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['yellow'], 'align': 'right',
             'num_format': '#,##0.00', 'font_name': 'Georgia'})
        wbf['total_float_yellow'].set_top()
        wbf['total_float_yellow'].set_bottom()
        wbf['total_float_yellow'].set_left()
        wbf['total_float_yellow'].set_right()
        
        wbf['total_number_yellow'] = workbook.add_format(
            {'align': 'right', 'bg_color': colors['yellow'], 'bold': 1, 'num_format': '#,##0', 'font_name': 'Georgia'})
        wbf['total_number_yellow'].set_top()
        wbf['total_number_yellow'].set_bottom()
        wbf['total_number_yellow'].set_left()
        wbf['total_number_yellow'].set_right()
        
        wbf['total_yellow'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['yellow'], 'align': 'center', 'font_name': 'Georgia'})
        wbf['total_yellow'].set_left()
        wbf['total_yellow'].set_right()
        wbf['total_yellow'].set_top()
        wbf['total_yellow'].set_bottom()

        wbf['total_float_orange'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['orange'], 'align': 'right',
             'num_format': '#,##0.00', 'font_name': 'Georgia'})
        wbf['total_float_orange'].set_top()
        wbf['total_float_orange'].set_bottom()            
        wbf['total_float_orange'].set_left()
        wbf['total_float_orange'].set_right()         
        
        wbf['total_number_orange'] = workbook.add_format(
            {'align': 'right', 'bg_color': colors['orange'], 'bold': 1, 'num_format': '#,##0', 'font_name': 'Georgia'})
        wbf['total_number_orange'].set_top()
        wbf['total_number_orange'].set_bottom()            
        wbf['total_number_orange'].set_left()
        wbf['total_number_orange'].set_right()
        
        wbf['total_orange'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['orange'], 'align': 'center', 'font_name': 'Georgia'})
        wbf['total_orange'].set_left()
        wbf['total_orange'].set_right()
        wbf['total_orange'].set_top()
        wbf['total_orange'].set_bottom()
        
        wbf['header_detail_space'] = workbook.add_format({'font_name': 'Georgia'})
        wbf['header_detail_space'].set_left()
        wbf['header_detail_space'].set_right()
        wbf['header_detail_space'].set_top()
        wbf['header_detail_space'].set_bottom()
        
        wbf['header_detail'] = workbook.add_format({'bg_color': '#E0FFC2', 'font_name': 'Georgia'})
        wbf['header_detail'].set_left()
        wbf['header_detail'].set_right()
        wbf['header_detail'].set_top()
        wbf['header_detail'].set_bottom()
        
        return wbf, workbook

    def button_to_get_pdf(self):
        """It will create the report using defined query"""
        where_conditions = []
        parameters = []
        state_value = ""
        currency = self.env.user.company_id.currency_id.symbol
        if self.start_date:
            where_conditions.append("account_move_line.date >= %s")
            parameters.append(self.start_date)
        if self.end_date:
            where_conditions.append("account_move_line.date <= %s")
            parameters.append(self.end_date)
        if self.company_id:
            where_conditions.append("account_move_line.company_id = %s")
            parameters.append(str(self.company_id.id))
        if self.state == 'posted':
            where_conditions.append("parent_state = 'posted'")
        if self.state == 'draft':
            where_conditions.append("parent_state in ('posted', 'draft')")
        if self.partner_ids:
            partner_ids = [partner.id for partner in self.partner_ids]
            where_conditions.append("partner_id IN %s")
            parameters.append(tuple(partner_ids))
        if self.journals_ids:
            journal_ids = [journal.id for journal in self.journals_ids]
            where_conditions.append("journal_id IN %s")
            parameters.append(tuple(journal_ids))
        where_query = " AND ".join(where_conditions)
        query = """
            SELECT
                res_partner.name AS partner,
                account_move_line.move_name AS invoice,
                SUM(account_move_line.debit)	   FILTER (WHERE account_account.code = '102011') AS accounts_receivable,
                SUM(account_move_line.credit)	   FILTER (WHERE account_account.code like '201017') AS vat_output,
                SUM(account_move_line.debit)	   FILTER (WHERE account_account.code like '104042') AS with_holding,
				SUM(account_move_line.credit)	   FILTER (WHERE account_account.code like '500001') AS sales_account
            FROM
                account_move_line
            JOIN
                account_account ON account_account.id = 
                account_move_line.account_id
            JOIN
                res_partner ON res_partner.id = 
                account_move_line.partner_id
            {}
            GROUP BY
                res_partner.name,
				account_move_line.move_name

        """.format("WHERE " + where_query if where_conditions else "")
        self.env.cr.execute(query, tuple(parameters))
        main_query = self.env.cr.dictfetchall()
        total_debit = 0.0
        total_vat = 0.0
        total_tax = 0.0
        total_sales = 0.0
        for rec in main_query:
            if rec['accounts_receivable'] != None:
                total_debit += rec['accounts_receivable']
            if rec['vat_output'] != None:
                total_vat += rec['vat_output']
            if rec['with_holding'] != None:
                total_tax += rec['with_holding']
            if rec['sales_account'] != None:
                total_sales += rec['sales_account']
        if self.state:
            state_value = selection_field[self.state]
        journals = str(self.journals_ids.mapped('name'))
        result = journals[1:-1].replace("'", "")
        data = {
            'query': main_query,
            'start_date': self.start_date,
            'end_date': self.end_date,
            'total_debit': round(total_debit, 2),
            'total_vat': round(total_vat, 2),
            'total_tax': round(total_tax, 2),
            'total_sales': round(total_sales, 2),
            'currency': currency,
            'state': state_value,
            'journals_name': result
        }
        return self.env.ref(
            'amr_customers_invoices_pdf.action_report_customers_invoices').report_action(
            self, data=data)
