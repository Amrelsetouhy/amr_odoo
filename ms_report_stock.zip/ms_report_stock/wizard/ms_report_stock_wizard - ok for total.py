import pytz
import xlsxwriter
import base64

from odoo import fields, models, api
from io import BytesIO
from datetime import datetime
from pytz import timezone


class MsReportStockWizard(models.TransientModel):
    _name = "ms.report.stock.wizard"
    _description = "Stock Report .xlsx"
    
    @api.model
    def get_default_date_tz(self):
        return pytz.UTC.localize(datetime.now()).astimezone(timezone(self.env.user.tz or 'UTC'))
    
    datas = fields.Binary('File', readonly=True)
    datas_fname = fields.Char('Filename', readonly=True)
    product_ids = fields.Many2many('product.product', 'ms_report_stock_product_rel', 'ms_report_stock_id', 
                                   'product_id', 'Products')
    categ_ids = fields.Many2many('product.category', 'ms_report_stock_categ_rel', 'ms_report_stock_id', 
                                 'categ_id', 'Categories')
    location_ids = fields.Many2many('stock.location', 'ms_report_stock_location_rel', 'ms_report_stock_id', 
                                    'location_id', 'Locations')
        
    def print_excel_report(self):
        data = self.read()[0]
        product_ids = data['product_ids']
        categ_ids = data['categ_ids']
        location_ids = data['location_ids']
        
        if product_ids:
            where_product_ids = " quant.product_id in %s" % str(tuple(product_ids)).replace(',)', ')')
            #raise UserWarning(str(where_product_ids))
        if categ_ids:
            if product_ids:
                x=1
            else:
                product_tmpl_ids_in_cate_rec = self.env['product.template'].search([('categ_id', 'in',categ_ids)])
                product_tmpl_ids = [tmpl.id for tmpl in product_tmpl_ids_in_cate_rec]
                product_Product_in_tmpl_rec = self.env['product.product'].search([('product_tmpl_id', 'in',product_tmpl_ids)])
                product_Product_ids = [prod.id for prod in product_Product_in_tmpl_rec]
                where_product_ids = " quant.product_id in %s" % str(tuple(product_Product_ids)).replace(',)', ')')
            #where_product_ids = " 1=1 "

        location_ids2 = self.env['stock.location'].search([])
        ids_location = [loc.id for loc in location_ids2]
        where_location_ids = " quant.location_id in %s" % str(tuple(ids_location)).replace(',)', ')')
        if location_ids:
            where_location_ids = " quant.location_id in %s" % str(tuple(location_ids)).replace(',)', ')')
            #raise UserWarning(where_location_ids)
        datetime_string = self.get_default_date_tz().strftime("%Y-%m-%d %H:%M:%S")
        date_string = self.get_default_date_tz().strftime("%Y-%m-%d")
        report_name = 'Stock Report'
        filename = '%s %s' % (report_name, date_string)
        
        columns = [
            ('No', 5, 'no', 'no'),
            ('Product', 20, 'char', 'char'),
            ('Product Category', 10, 'char', 'char'),
            ('Location', 20, 'char', 'char'),
            ('Start_QTY', 10, 'float', 'float'),
            ('IN_QTY', 10, 'float', 'float'),
            ('OUT_QTY', 10, 'float', 'float'),
	        ('Ret From WIP', 10, 'float', 'float'),
	        ('Ret To WIP', 10, 'float', 'float'),
	        ('Ret To Vendor', 10, 'float', 'float'),
            ('Total Stock', 15, 'float', 'float'),
            ('Stock In Location ', 20, 'float', 'float'),
            ('Reserved', 10, 'float', 'float'),
            ('Available', 10, 'float', 'float'),
        ]

        datetime_format = '%Y-%m-%d %H:%M:%S'
        utc = datetime.now().strftime(datetime_format)
        utc = datetime.strptime(utc, datetime_format)
        tz = self.get_default_date_tz().strftime(datetime_format)
        tz = datetime.strptime(tz, datetime_format)
        duration = tz - utc
        hours = duration.seconds / 60 / 60
        if hours > 1 or hours < 1:
            hours = str(hours) + ' hours'
        else:
            hours = str(hours) + ' hour'
        
        query = """
WITH ranked_data AS (
SELECT 
    prod_tmpl.name->>'en_US' AS product_name,  -- Extract the value associated with the 'en_US' key
    categ.name as prod_categ, 
    loc.complete_name as location,
    quant.in_date + interval '%s' as date_in, 
    date_part('days', now() - (quant.in_date + interval '%s')) as aging,
    SUM(CASE WHEN sml.reference LIKE '%%Quantity Updated 2024-12-31%%' AND sml.location_dest_id <> 14 THEN sml.qty_done ELSE 0 END) as start_qty,
    SUM(CASE WHEN sm.state = 'done' AND sm.picking_type_id in (1,10,19) AND sml.qty_done > 0 THEN sml.qty_done ELSE 0 END) as in_qty,
    SUM(CASE WHEN sm.state = 'done' AND sm.picking_type_id in (6,15,24) AND sml.qty_done > 0 AND sm.location_id = 5 THEN sml.qty_done ELSE 0 END) as ret_from_cust_qty,
	SUM(CASE WHEN sm.state = 'done' AND sm.picking_type_id in (6,15,24) AND sml.qty_done > 0 AND sm.location_dest_id = 5 THEN sml.qty_done ELSE 0 END) as ret_to_cust_qty,
	SUM(CASE WHEN sm.state = 'done' AND sm.picking_type_id in (6,15,24) AND sml.qty_done > 0 AND sm.location_dest_id = 4 THEN sml.qty_done ELSE 0 END) as ret_to_vend_qty,
    SUM(CASE WHEN sm.state = 'done' AND sm.picking_type_id in (28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45) AND sml.qty_done > 0 THEN sml.qty_done ELSE 0 END) as out_qty,
-- Net stock calculation by subtracting out_qty from in_qty
    SUM(CASE WHEN sml.reference LIKE '%%Quantity Updated 2024-12-31%%' AND sml.location_dest_id <> 14 THEN sml.qty_done ELSE 0 END)
    +
    SUM(CASE WHEN sm.state = 'done' AND sm.picking_type_id in (1,10,19) AND sm.product_qty > 0 THEN sml.qty_done ELSE 0 END)
	+
	SUM(CASE WHEN sm.state = 'done' AND sm.picking_type_id in (6,15,24) AND sm.product_qty > 0 AND sm.location_id = 5 THEN sml.qty_done ELSE 0 END)
    -
	SUM(CASE WHEN sm.state = 'done' AND sm.picking_type_id in (6,15,24) AND sm.product_qty > 0 AND sm.location_dest_id = 5 THEN sml.qty_done ELSE 0 END)
	-
	SUM(CASE WHEN sm.state = 'done' AND sm.picking_type_id in (6,15,24) AND sm.product_qty > 0 AND sm.location_dest_id = 4 THEN sml.qty_done ELSE 0 END)
	-	
    SUM(CASE WHEN sm.state = 'done' AND sm.picking_type_id in (28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45) AND sm.product_qty > 0 THEN sml.qty_done ELSE 0 END) 
    as net_stock,
    quant.quantity as total_product, 
    quant.reserved_quantity as reserved,

    quant.quantity - quant.reserved_quantity as stock, 
    -- Count of records from stock_move that affected out_qty
    COUNT(CASE WHEN sm.state LIKE 'done' AND sm.picking_type_id in (28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45) AND sm.product_qty > 0 THEN sm.id ELSE NULL END) as out_qty_count,
    -- Concatenate reference and quantity as (reference,quantity)
    STRING_AGG(CONCAT('(', sml.reference, ',', sml.qty_done, ')'), ', ') AS reference_and_quantity,
    -- Row number to identify the first row of each product
    ROW_NUMBER() OVER (PARTITION BY prod_tmpl.name ORDER BY quant.in_date) AS row_num
        
FROM 
    stock_quant quant
LEFT JOIN 
    product_product prod on prod.id = quant.product_id
LEFT JOIN 
    stock_location loc on loc.id = quant.location_id
LEFT JOIN 
    product_template prod_tmpl on prod_tmpl.id = prod.product_tmpl_id
LEFT JOIN 
    product_category categ on categ.id = prod_tmpl.categ_id
LEFT JOIN 
    stock_move sm on sm.product_id = quant.product_id
LEFT JOIN 
    stock_move_line sml on sml.move_id = sm.id    
LEFT JOIN 
    stock_warehouse wh on wh.id = sm.warehouse_id   

WHERE 
    %s and %s
AND loc.usage = 'internal' 
GROUP BY 
    prod_tmpl.name, categ.name, loc.complete_name, quant.in_date,quant.quantity,quant.reserved_quantity,quant.quantity - quant.reserved_quantity
ORDER BY 
    date_in
 )

SELECT
	--product_name,
	CASE WHEN row_num = 1 THEN product_name ELSE '' END as product,
	CASE WHEN row_num = 1 THEN prod_categ ELSE '' END as prod_categ,
	location,
    CASE WHEN row_num = 1 THEN start_qty ELSE NULL END as start_qty,
    CASE WHEN row_num = 1 THEN in_qty ELSE NULL END as in_qty,
    CASE WHEN row_num = 1 THEN out_qty ELSE NULL END as out_qty,
    CASE WHEN row_num = 1 THEN ret_from_cust_qty ELSE NULL END as ret_from_cust_qty,
    CASE WHEN row_num = 1 THEN ret_to_cust_qty ELSE NULL END as ret_to_cust_qty,
    CASE WHEN row_num = 1 THEN ret_to_vend_qty ELSE NULL END as ret_to_vend_qty,
    CASE WHEN row_num = 1 THEN net_stock ELSE NULL END as net_stock,
    total_product,
    reserved,
    stock
FROM ranked_data
ORDER BY product_name, row_num;
   
        """
        
        self._cr.execute(query % (hours, hours, where_product_ids, where_location_ids))
        result = self._cr.fetchall()
        #raise UserWarning(result)
        fp = BytesIO()
        workbook = xlsxwriter.Workbook(fp)
        wbf, workbook = self.add_workbook_format(workbook)

        worksheet = workbook.add_worksheet(report_name)
        worksheet.merge_range('A2:I3', report_name, wbf['title_doc'])

        row = 5

        col = 0
        for column in columns:
            column_name = column[0]
            column_width = column[1]
            worksheet.set_column(col, col, column_width)
            worksheet.write(row-1, col, column_name, wbf['header_orange'])

            col += 1
        
        row += 1
        no = 1

        column_float_number = {}
        for res in result:
            col = 0
            for column in columns:
                column_type = column[2]
                if column_type == 'char':
                    col_value = res[col-1] if res[col-1] else ''
                    wbf_value = wbf['content']
                elif column_type == 'no':
                    col_value = no
                    wbf_value = wbf['content']
                elif column_type == 'datetime':
                    col_value = res[col - 1].strftime('%Y-%m-%d %H:%M:%S') if res[col - 1] else ''
                    wbf_value = wbf['content']
                else:
                    col_value = res[col-1] if res[col-1] else 0
                    if column_type == 'float':
                        wbf_value = wbf['content_float']
                    else:  # number
                        wbf_value = wbf['content_number']
                    column_float_number[col] = column_float_number.get(col, 0) + col_value
                if isinstance(col_value, dict):
                    col_value = list(col_value.values())[0]
                worksheet.write(row-1, col, col_value, wbf_value)

                col += 1
            
            row += 1
            no += 1
        
        worksheet.merge_range('A%s:B%s' % (row, row), 'Grand Total', wbf['total_orange'])
        for x in range(len(columns)):
            if x in (0,1):
                continue
            column_type = columns[x][3]
            if column_type == 'char':
                worksheet.write(row-1, x, '', wbf['total_orange'])
            else:
                if column_type == 'float':
                    wbf_value = wbf['total_float_orange']
                else:  # number
                    wbf_value = wbf['total_number_orange']
                if x in column_float_number:
                    worksheet.write(row-1, x, column_float_number[x], wbf_value)
                else:
                    worksheet.write(row-1, x, 0, wbf_value)
        
        worksheet.write('A%s' % (row+2), 'Date %s (%s)' % (
            datetime_string, self.env.user.tz or 'UTC'), wbf['content_datetime'])
        workbook.close()
        out = base64.encodebytes(fp.getvalue())
        self.write({'datas': out, 'datas_fname': filename})
        fp.close()
        filename += '%2Exlsx'

        return {
            'type': 'ir.actions.act_url',
            'target': 'new',
            'url': 'web/content/?model='+self._name+'&id='+str(self.id)+'&field=datas&download=true&filename='+filename,
        }

    def add_workbook_format(self, workbook):
        colors = {
            'white_orange': '#FFFFDB',
            'orange': '#FFC300',
            'red': '#FF0000',
            'yellow': '#F6FA03',
        }

        wbf = {}
        wbf['header'] = workbook.add_format(
            {'bold': 1, 'align': 'center', 'bg_color': '#FFFFDB', 'font_color': '#000000', 'font_name': 'Georgia'})
        wbf['header'].set_border()

        wbf['header_orange'] = workbook.add_format({
            'bold': 1, 'align': 'center', 'bg_color': colors['orange'], 'font_color': '#000000', 'font_name': 'Georgia'})
        wbf['header_orange'].set_border()

        wbf['header_yellow'] = workbook.add_format(
            {'bold': 1, 'align': 'center', 'bg_color': colors['yellow'], 
             'font_color': '#000000', 'font_name': 'Georgia'})
        wbf['header_yellow'].set_border()
        
        wbf['header_no'] = workbook.add_format(
            {'bold': 1, 'align': 'center', 'bg_color': '#FFFFDB', 'font_color': '#000000', 'font_name': 'Georgia'})
        wbf['header_no'].set_border()
        wbf['header_no'].set_align('vcenter')
                
        wbf['footer'] = workbook.add_format({'align': 'left', 'font_name': 'Georgia'})
        
        wbf['content_datetime'] = workbook.add_format({'num_format': 'yyyy-mm-dd hh:mm:ss', 'font_name': 'Georgia'})
        wbf['content_datetime'].set_left()
        wbf['content_datetime'].set_right()
        
        wbf['content_date'] = workbook.add_format({'num_format': 'yyyy-mm-dd', 'font_name': 'Georgia'})
        wbf['content_date'].set_left()
        wbf['content_date'].set_right() 
        
        wbf['title_doc'] = workbook.add_format({
            'bold': True,
            'align': 'center',
            'valign': 'vcenter',
            'font_size': 20,
            'font_name': 'Georgia',
        })
        
        wbf['company'] = workbook.add_format({'align': 'left', 'font_name': 'Georgia'})
        wbf['company'].set_font_size(11)
        
        wbf['content'] = workbook.add_format()
        wbf['content'].set_left()
        wbf['content'].set_right() 
        
        wbf['content_float'] = workbook.add_format({'align': 'right', 'num_format': '#,##0.00', 'font_name': 'Georgia'})
        wbf['content_float'].set_right() 
        wbf['content_float'].set_left()

        wbf['content_number'] = workbook.add_format({'align': 'right', 'num_format': '#,##0', 'font_name': 'Georgia'})
        wbf['content_number'].set_right() 
        wbf['content_number'].set_left() 
        
        wbf['content_percent'] = workbook.add_format({'align': 'right', 'num_format': '0.00%', 'font_name': 'Georgia'})
        wbf['content_percent'].set_right() 
        wbf['content_percent'].set_left() 
                
        wbf['total_float'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['white_orange'], 'align': 'right', 
             'num_format': '#,##0.00', 'font_name': 'Georgia'})
        wbf['total_float'].set_top()
        wbf['total_float'].set_bottom()            
        wbf['total_float'].set_left()
        wbf['total_float'].set_right()         
        
        wbf['total_number'] = workbook.add_format(
            {'align': 'right', 'bg_color': colors['white_orange'], 'bold': 1, 
             'num_format': '#,##0', 'font_name': 'Georgia'})
        wbf['total_number'].set_top()
        wbf['total_number'].set_bottom()            
        wbf['total_number'].set_left()
        wbf['total_number'].set_right()
        
        wbf['total'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['white_orange'], 
             'align': 'center', 'font_name': 'Georgia'})
        wbf['total'].set_left()
        wbf['total'].set_right()
        wbf['total'].set_top()
        wbf['total'].set_bottom()

        wbf['total_float_yellow'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['yellow'], 'align': 'right',
             'num_format': '#,##0.00', 'font_name': 'Georgia'})
        wbf['total_float_yellow'].set_top()
        wbf['total_float_yellow'].set_bottom()
        wbf['total_float_yellow'].set_left()
        wbf['total_float_yellow'].set_right()
        
        wbf['total_number_yellow'] = workbook.add_format(
            {'align': 'right', 'bg_color': colors['yellow'], 'bold': 1, 'num_format': '#,##0', 'font_name': 'Georgia'})
        wbf['total_number_yellow'].set_top()
        wbf['total_number_yellow'].set_bottom()
        wbf['total_number_yellow'].set_left()
        wbf['total_number_yellow'].set_right()
        
        wbf['total_yellow'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['yellow'], 'align': 'center', 'font_name': 'Georgia'})
        wbf['total_yellow'].set_left()
        wbf['total_yellow'].set_right()
        wbf['total_yellow'].set_top()
        wbf['total_yellow'].set_bottom()

        wbf['total_float_orange'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['orange'], 'align': 'right',
             'num_format': '#,##0.00', 'font_name': 'Georgia'})
        wbf['total_float_orange'].set_top()
        wbf['total_float_orange'].set_bottom()            
        wbf['total_float_orange'].set_left()
        wbf['total_float_orange'].set_right()         
        
        wbf['total_number_orange'] = workbook.add_format(
            {'align': 'right', 'bg_color': colors['orange'], 'bold': 1, 'num_format': '#,##0', 'font_name': 'Georgia'})
        wbf['total_number_orange'].set_top()
        wbf['total_number_orange'].set_bottom()            
        wbf['total_number_orange'].set_left()
        wbf['total_number_orange'].set_right()
        
        wbf['total_orange'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['orange'], 'align': 'center', 'font_name': 'Georgia'})
        wbf['total_orange'].set_left()
        wbf['total_orange'].set_right()
        wbf['total_orange'].set_top()
        wbf['total_orange'].set_bottom()
        
        wbf['header_detail_space'] = workbook.add_format({'font_name': 'Georgia'})
        wbf['header_detail_space'].set_left()
        wbf['header_detail_space'].set_right()
        wbf['header_detail_space'].set_top()
        wbf['header_detail_space'].set_bottom()
        
        wbf['header_detail'] = workbook.add_format({'bg_color': '#E0FFC2', 'font_name': 'Georgia'})
        wbf['header_detail'].set_left()
        wbf['header_detail'].set_right()
        wbf['header_detail'].set_top()
        wbf['header_detail'].set_bottom()
        
        return wbf, workbook
