# -*- coding: utf-8 -*-
{
    "name": "Stock Report",
    "summary": """
        Download stock report in excel format
    """,
    "description": """
    """,
    "author": "Miftahussalam",
    "website": "https://blog.miftahussalam.com/",
    "category": "Inventory/Inventory",
    "version": "16.0.1.0.0",
    "depends": [
        "base",
        "stock",
    ],
    "data": [
        "security/ir.model.access.csv",
        "wizard/ms_report_stock_wizard.xml",
    ],
    "demo": [

    ],
    "images": [
        "static/description/images/main_screenshot.png",
    ],
    "license": "LGPL-3",
}
