{
    'name': 'Custom Server Action Decoder',
    'version': '1.0',
    'summary': 'Adds support for decoding and executing Base64-encoded server action code.',
    'author': 'Amr Abdel Aziz',
    'depends': ['base'],
    'data': [],
    'installable': True,
    'application': False,
    'auto_install': False,
}
