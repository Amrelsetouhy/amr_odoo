import base64
import logging
from odoo import models, api
from odoo.exceptions import UserError

# XOR decryption function
def xor_decrypt(data, key):
    return bytes([b ^ key for b in data])

# Set the decryption key
KEY = 56

_logger = logging.getLogger(__name__)

class IrActionsServer(models.Model):
    _inherit = 'ir.actions.server'

    def execute_encoded_code(self, encoded_string, records):
        # Decode the Base64 string
        try:
            # First, decode the Base64 string
            decoded_base64 = base64.b64decode(encoded_string)

            # Then, decrypt using XOR
            decrypted_code = xor_decrypt(decoded_base64, KEY)

            # Try to decode the decrypted bytes to a UTF-8 string
            try:
                decrypted_code_str = decrypted_code.decode('utf-8')
            except UnicodeDecodeError:
                # If decoding to UTF-8 fails, log the error and try latin-1
                _logger.error("UTF-8 decoding failed, attempting latin-1.")
                decrypted_code_str = decrypted_code.decode('latin-1')  # Fallback to latin-1

        except Exception as e:
            raise UserError(f"Error decoding or decrypting the code: {e}")
        
        # Log the decoded code for debugging
        _logger.info(f"Decoded Code: {decrypted_code_str}")

        # Validate records
        if not records:
            raise UserError("No records provided to execute the server action.")
        
        # Execute the code
        try:
            exec(decrypted_code_str, {
                'env': self.env,
                'model': self.env[records._name],  # Use the model of the passed records
                'records': records,
            })
        except Exception as e:
            raise UserError(f"Error executing code: {e}")
