# __init__.py in the root module directory

from . import models

