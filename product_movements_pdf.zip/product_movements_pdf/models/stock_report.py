# product_movements_pdf/models/stock_report.py
from odoo import models, api

class StockReport(models.AbstractModel):
    _name = 'report.product_movements_pdf.stock_report_template'
    _description = 'Stock Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        wizard = self.env['stock.report.wizard'].browse(docids)
        product_id = wizard.product_id.id
        product_name = wizard.product_id.name  # Fetch the product's name from the product_id field
        start_date = wizard.start_date
        end_date = wizard.end_date

        query = """
        WITH stock_operations AS (
            SELECT 
                svl.product_id,
                svl.quantity AS qty,
                svl.unit_cost AS value_unit,
                svl.quantity * svl.unit_cost AS t_value,
                sm.picking_type_id,
                sm.state,
                sm.product_qty,
                sm.location_id,
                sm.location_dest_id,
                rp.name AS receive_from_partner_id,
                dp.name AS delivery_address_partner_id,
                svl.create_date,
                CASE 
                    WHEN sm.picking_type_id IN (1, 10, 19) THEN 'incoming'
                    WHEN sm.picking_type_id IN (28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45) THEN 'outgoing'
                    WHEN sm.picking_type_id IN (6, 15, 24) THEN 'inventory adjustment'
                    ELSE '31-12-24 stock'
                END AS operation_type,
                SUM(svl.quantity) OVER (PARTITION BY svl.product_id ORDER BY svl.create_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS stock_after_operation,
                SUM(svl.quantity) OVER (PARTITION BY svl.product_id ORDER BY svl.create_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) * svl.unit_cost AS stock_value,
                rp.name AS from_partner,
                dp.name AS delivery_address,
                TO_CHAR(svl.create_date, 'DD/MM/YY') AS date_of_operation
            FROM stock_valuation_layer svl
            JOIN stock_move sm ON sm.id = svl.stock_move_id
            LEFT JOIN stock_picking sp ON sp.id = sm.picking_id
            LEFT JOIN res_partner rp ON rp.id = sp.partner_id
            LEFT JOIN res_partner dp ON dp.id = sp.partner_id
            WHERE svl.product_id = %s
              AND sm.state = 'done'
              AND svl.create_date BETWEEN %s AND %s
        )
        SELECT 
            qty,
            value_unit,
            t_value AS "T.value",
            operation_type,
            stock_after_operation,
            stock_value,
            from_partner,
            date_of_operation
        FROM stock_operations
        ORDER BY create_date;
        """

        self.env.cr.execute(query, (product_id, start_date, end_date))
        results = self.env.cr.dictfetchall()

        return {
            'doc_ids': docids,
            'doc_model': 'stock.report.wizard',
            'data': data,
            'results': results,
            'product_name': product_name,  # Pass the product's name to the template
        }