import pytz
import xlsxwriter
import base64
from datetime import timedelta
from odoo import fields, models, api
from io import BytesIO
from datetime import datetime
from pytz import timezone


class MsReportStockWizard(models.TransientModel):
    _name = "ms.report.stock.wizard"
    _description = "Stock Report .xlsx"
    
    @api.model
    def get_default_date_tz(self):
        return pytz.UTC.localize(datetime.now()).astimezone(timezone(self.env.user.tz or 'UTC'))
    
    datas = fields.Binary('File', readonly=True)
    datas_fname = fields.Char('Filename', readonly=True)
    product_ids = fields.Many2many('product.product', 'ms_report_stock_product_rel', 'ms_report_stock_id', 
                                   'product_id', 'Products')
    categ_ids = fields.Many2many('product.category', 'ms_report_stock_categ_rel', 'ms_report_stock_id', 
                                 'categ_id', 'Categories')
    end_date = fields.Date(string ='End Date')
    warehouse_id = fields.Many2one('stock.warehouse', string='Warehouse')    
    def print_excel_report(self):
        data = self.read()[0]
        product_ids = data['product_ids']
        categ_ids = data['categ_ids']
        end_date = data['end_date']
        
        #warehouse_id = data['warehouse_id'][0]
        if data['warehouse_id']:  # التأكد من وجود قيمة قبل استخراج ID
            warehouse_id = data['warehouse_id'][0]
            if warehouse_id:
                if warehouse_id==1:
                    where_products_of_warehouse= "pp.default_code LIKE 'S%'"
                elif warehouse_id==2:
                    where_products_of_warehouse= "pp.default_code LIKE 'A%'"
                elif warehouse_id==3:
                    where_products_of_warehouse= "pp.default_code LIKE 'M%'"
        else:
             where_products_of_warehouse ="1=1"
        if end_date:
            str_end_date="'"+str(end_date)+"'"
            end_date_plus_day = self.end_date + timedelta(days=1)
            where_date = "sml.date < "+"'"+str(end_date_plus_day)+"'"
                
        #location_ids2 = self.env['stock.location'].search([])
        #ids_location = [loc.id for loc in location_ids2]
        #where_location_ids = " quant.location_id in %s" % str(tuple(ids_location)).replace(',)', ')')
        #if location_ids:
           # where_location_ids = " quant.location_id in %s" % str(tuple(location_ids)).replace(',)', ')')
            #raise UserWarning(where_location_ids)
        datetime_string = self.get_default_date_tz().strftime("%Y-%m-%d %H:%M:%S")
        date_string = self.get_default_date_tz().strftime("%Y-%m-%d")
        report_name = 'Stock Report In Quantities and Values'+ 'Until '+str_end_date
        filename = '%s %s' % (report_name, date_string)
        
        columns = [
            ('No', 5, 'no', 'no'),
            ('code', 20, 'char', 'char'),
            ('product', 20, 'char', 'char'),
            ('Product Category', 10, 'char', 'char'),
            ('Start_QTY', 10, 'float', 'float'),
            ('Start_Val', 10, 'float', 'float'),
            ('IN_QTY', 10, 'float', 'float'),
            ('IN_VAL', 10, 'float', 'float'),
            ('OUT_QTY', 10, 'float', 'float'),
            ('OUT_VAL', 10, 'float', 'float'),
            ('STOCK_QTY', 10, 'float', 'float'),
            ('STOCK_VAL', 10, 'float', 'float'),
        ]

        datetime_format = '%Y-%m-%d %H:%M:%S'
        utc = datetime.now().strftime(datetime_format)
        utc = datetime.strptime(utc, datetime_format)
        tz = self.get_default_date_tz().strftime(datetime_format)
        tz = datetime.strptime(tz, datetime_format)
        duration = tz - utc
        hours = duration.seconds / 60 / 60
        if hours > 1 or hours < 1:
            hours = str(hours) + ' hours'
        else:
            hours = str(hours) + ' hour'
        
        query = """
SELECT 
    pp.default_code AS product_code,
    pt.name AS product_name,
    pc.name AS category_name,
    -- quant.in_date + interval '%s' as date_in, 
    -- date_part('days', now() - (quant.in_date + interval '%s')) as aging,

    -- الكمية الابتدائية بناءً على الجرد بتاريخ 2024-12-31
    COALESCE(SUM(CASE 
        WHEN sm.reference ILIKE '%%Quantity Updated 2024-12-31%%' THEN svl.quantity 
        ELSE 0 END), 0) AS start_qty,

    COALESCE(SUM(CASE 
        WHEN sm.reference ILIKE '%%Quantity Updated 2024-12-31%%' THEN svl.value 
        ELSE 0 END), 0) AS start_value,

    -- الكمية الداخلة بعد الجرد
    COALESCE(SUM(CASE 
        WHEN sp.picking_type_id IN (
            SELECT id FROM stock_picking_type WHERE code = 'incoming'
        ) AND sm.reference NOT ILIKE '%%Quantity Updated 2024-12-31%%' THEN svl.quantity
        ELSE 0 END), 0) AS input_qty,

    COALESCE(SUM(CASE 
        WHEN sp.picking_type_id IN (
            SELECT id FROM stock_picking_type WHERE code = 'incoming'
        ) AND sm.reference NOT ILIKE '%%Quantity Updated 2024-12-31%%' THEN svl.value
        ELSE 0 END), 0) AS input_value,

    -- الكمية الخارجة بعد الجرد
    COALESCE(SUM(CASE 
        WHEN sp.picking_type_id IN (
            SELECT id FROM stock_picking_type WHERE code = 'outgoing'
        ) AND sm.reference NOT ILIKE '%%Quantity Updated 2024-12-31%%' THEN ABS(svl.quantity)
        ELSE 0 END), 0) AS output_qty,

    COALESCE(SUM(CASE 
        WHEN sp.picking_type_id IN (
            SELECT id FROM stock_picking_type WHERE code = 'outgoing'
        ) AND sm.reference NOT ILIKE '%%Quantity Updated 2024-12-31%%' THEN ABS(svl.value)
        ELSE 0 END), 0) AS output_value,

    -- الكمية النهائية
    COALESCE(SUM(svl.quantity), 0) AS final_qty,
    COALESCE(SUM(svl.value), 0) AS final_value

FROM stock_valuation_layer svl
JOIN product_product pp ON svl.product_id = pp.id
JOIN product_template pt ON pp.product_tmpl_id = pt.id
JOIN product_category pc ON pt.categ_id = pc.id
LEFT JOIN stock_move sm ON svl.stock_move_id = sm.id
LEFT JOIN stock_move_line sml ON sml.move_id = sm.id  -- ✅ ربطنا مع stock_move_line
LEFT JOIN stock_picking sp ON sm.picking_id = sp.id

WHERE 1=1
--and pc.id in(15,22)
  and %s and %s and %s and %s
   
  --And pp.default_code LIKE 'A%%'
  --AND sml.date < '2025-02-1'  -- ✅ استخدمنا تاريخ الحركة الحقيقي
  --AND pc.name not like '%%-%%'


GROUP BY pp.default_code, pt.name, pc.name;
   
        """
       # raise UserWarning(where_product_ids)

        if categ_ids:
            if product_ids:
                where_category_ids="1=1"
                where_product_ids = "pp.id in %s" % str(tuple(product_ids)).replace(',)', ')')
            else:
               where_category_ids = "pc.id in %s" % str(tuple(categ_ids)).replace(',)', ')')
               where_product_ids = "1=1"
        else:
            if product_ids:
                where_category_ids="1=1"
                where_product_ids = "pp.id in %s" % str(tuple(product_ids)).replace(',)', ')')
            else:
                 raise UserWarning("Pls select products or product Category") 

        #raise UserWarning(query)      

        #self._cr.execute(query)       
        self._cr.execute(query % (hours,hours,where_product_ids,where_category_ids,where_products_of_warehouse,where_date))      


        result = self._cr.fetchall()
        #raise UserWarning(result)
        fp = BytesIO()
        workbook = xlsxwriter.Workbook(fp)
        wbf, workbook = self.add_workbook_format(workbook)

        worksheet = workbook.add_worksheet(report_name)
        worksheet.merge_range('A2:I3', report_name, wbf['title_doc'])

        row = 5

        col = 0
        for column in columns:
            column_name = column[0]
            column_width = column[1]
            worksheet.set_column(col, col, column_width)
            worksheet.write(row-1, col, column_name, wbf['header_orange'])

            col += 1
        
        row += 1
        no = 1

        column_float_number = {}
        for res in result:
            col = 0
            for column in columns:
                column_type = column[2]
                if column_type == 'char':
                    col_value = res[col-1] if res[col-1] else ''
                    wbf_value = wbf['content']
                elif column_type == 'no':
                    col_value = no
                    wbf_value = wbf['content']
                elif column_type == 'datetime':
                    col_value = res[col - 1].strftime('%Y-%m-%d %H:%M:%S') if res[col - 1] else ''
                    wbf_value = wbf['content']
                else:
                    col_value = res[col-1] if res[col-1] else 0
                    if column_type == 'float':
                        wbf_value = wbf['content_float']
                    else:  # number
                        wbf_value = wbf['content_number']
                    column_float_number[col] = column_float_number.get(col, 0) + col_value
                if isinstance(col_value, dict):
                    col_value = list(col_value.values())[0]
                worksheet.write(row-1, col, col_value, wbf_value)

                col += 1
            
            row += 1
            no += 1
        
        worksheet.merge_range('A%s:B%s' % (row, row), 'Grand Total', wbf['total_orange'])
        for x in range(len(columns)):
            if x in (0,1):
                continue
            column_type = columns[x][3]
            if column_type == 'char':
                worksheet.write(row-1, x, '', wbf['total_orange'])
            else:
                if column_type == 'float':
                    wbf_value = wbf['total_float_orange']
                else:  # number
                    wbf_value = wbf['total_number_orange']
                if x in column_float_number:
                    worksheet.write(row-1, x, column_float_number[x], wbf_value)
                else:
                    worksheet.write(row-1, x, 0, wbf_value)
        
        worksheet.write('A%s' % (row+2), 'Date %s (%s)' % (
            datetime_string, self.env.user.tz or 'UTC'), wbf['content_datetime'])
        workbook.close()
        out = base64.encodebytes(fp.getvalue())
        self.write({'datas': out, 'datas_fname': filename})
        fp.close()
        filename += '%2Exlsx'

        return {
            'type': 'ir.actions.act_url',
            'target': 'new',
            'url': 'web/content/?model='+self._name+'&id='+str(self.id)+'&field=datas&download=true&filename='+filename,
        }

    def add_workbook_format(self, workbook):
        colors = {
            'white_orange': '#FFFFDB',
            'orange': '#FFC300',
            'red': '#FF0000',
            'yellow': '#F6FA03',
        }

        wbf = {}
        wbf['header'] = workbook.add_format(
            {'bold': 1, 'align': 'center', 'bg_color': '#FFFFDB', 'font_color': '#000000', 'font_name': 'Georgia'})
        wbf['header'].set_border()

        wbf['header_orange'] = workbook.add_format({
            'bold': 1, 'align': 'center', 'bg_color': colors['orange'], 'font_color': '#000000', 'font_name': 'Georgia'})
        wbf['header_orange'].set_border()

        wbf['header_yellow'] = workbook.add_format(
            {'bold': 1, 'align': 'center', 'bg_color': colors['yellow'], 
             'font_color': '#000000', 'font_name': 'Georgia'})
        wbf['header_yellow'].set_border()
        
        wbf['header_no'] = workbook.add_format(
            {'bold': 1, 'align': 'center', 'bg_color': '#FFFFDB', 'font_color': '#000000', 'font_name': 'Georgia'})
        wbf['header_no'].set_border()
        wbf['header_no'].set_align('vcenter')
                
        wbf['footer'] = workbook.add_format({'align': 'left', 'font_name': 'Georgia'})
        
        wbf['content_datetime'] = workbook.add_format({'num_format': 'yyyy-mm-dd hh:mm:ss', 'font_name': 'Georgia'})
        wbf['content_datetime'].set_left()
        wbf['content_datetime'].set_right()
        
        wbf['content_date'] = workbook.add_format({'num_format': 'yyyy-mm-dd', 'font_name': 'Georgia'})
        wbf['content_date'].set_left()
        wbf['content_date'].set_right() 
        
        wbf['title_doc'] = workbook.add_format({
            'bold': True,
            'align': 'center',
            'valign': 'vcenter',
            'font_size': 20,
            'font_name': 'Georgia',
        })
        
        wbf['company'] = workbook.add_format({'align': 'left', 'font_name': 'Georgia'})
        wbf['company'].set_font_size(11)
        
        wbf['content'] = workbook.add_format()
        wbf['content'].set_left()
        wbf['content'].set_right() 
        
        wbf['content_float'] = workbook.add_format({'align': 'right', 'num_format': '#,##0.00', 'font_name': 'Georgia'})
        wbf['content_float'].set_right() 
        wbf['content_float'].set_left()

        wbf['content_number'] = workbook.add_format({'align': 'right', 'num_format': '#,##0', 'font_name': 'Georgia'})
        wbf['content_number'].set_right() 
        wbf['content_number'].set_left() 
        
        wbf['content_percent'] = workbook.add_format({'align': 'right', 'num_format': '0.00%', 'font_name': 'Georgia'})
        wbf['content_percent'].set_right() 
        wbf['content_percent'].set_left() 
                
        wbf['total_float'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['white_orange'], 'align': 'right', 
             'num_format': '#,##0.00', 'font_name': 'Georgia'})
        wbf['total_float'].set_top()
        wbf['total_float'].set_bottom()            
        wbf['total_float'].set_left()
        wbf['total_float'].set_right()         
        
        wbf['total_number'] = workbook.add_format(
            {'align': 'right', 'bg_color': colors['white_orange'], 'bold': 1, 
             'num_format': '#,##0', 'font_name': 'Georgia'})
        wbf['total_number'].set_top()
        wbf['total_number'].set_bottom()            
        wbf['total_number'].set_left()
        wbf['total_number'].set_right()
        
        wbf['total'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['white_orange'], 
             'align': 'center', 'font_name': 'Georgia'})
        wbf['total'].set_left()
        wbf['total'].set_right()
        wbf['total'].set_top()
        wbf['total'].set_bottom()

        wbf['total_float_yellow'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['yellow'], 'align': 'right',
             'num_format': '#,##0.00', 'font_name': 'Georgia'})
        wbf['total_float_yellow'].set_top()
        wbf['total_float_yellow'].set_bottom()
        wbf['total_float_yellow'].set_left()
        wbf['total_float_yellow'].set_right()
        
        wbf['total_number_yellow'] = workbook.add_format(
            {'align': 'right', 'bg_color': colors['yellow'], 'bold': 1, 'num_format': '#,##0', 'font_name': 'Georgia'})
        wbf['total_number_yellow'].set_top()
        wbf['total_number_yellow'].set_bottom()
        wbf['total_number_yellow'].set_left()
        wbf['total_number_yellow'].set_right()
        
        wbf['total_yellow'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['yellow'], 'align': 'center', 'font_name': 'Georgia'})
        wbf['total_yellow'].set_left()
        wbf['total_yellow'].set_right()
        wbf['total_yellow'].set_top()
        wbf['total_yellow'].set_bottom()

        wbf['total_float_orange'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['orange'], 'align': 'right',
             'num_format': '#,##0.00', 'font_name': 'Georgia'})
        wbf['total_float_orange'].set_top()
        wbf['total_float_orange'].set_bottom()            
        wbf['total_float_orange'].set_left()
        wbf['total_float_orange'].set_right()         
        
        wbf['total_number_orange'] = workbook.add_format(
            {'align': 'right', 'bg_color': colors['orange'], 'bold': 1, 'num_format': '#,##0', 'font_name': 'Georgia'})
        wbf['total_number_orange'].set_top()
        wbf['total_number_orange'].set_bottom()            
        wbf['total_number_orange'].set_left()
        wbf['total_number_orange'].set_right()
        
        wbf['total_orange'] = workbook.add_format(
            {'bold': 1, 'bg_color': colors['orange'], 'align': 'center', 'font_name': 'Georgia'})
        wbf['total_orange'].set_left()
        wbf['total_orange'].set_right()
        wbf['total_orange'].set_top()
        wbf['total_orange'].set_bottom()
        
        wbf['header_detail_space'] = workbook.add_format({'font_name': 'Georgia'})
        wbf['header_detail_space'].set_left()
        wbf['header_detail_space'].set_right()
        wbf['header_detail_space'].set_top()
        wbf['header_detail_space'].set_bottom()
        
        wbf['header_detail'] = workbook.add_format({'bg_color': '#E0FFC2', 'font_name': 'Georgia'})
        wbf['header_detail'].set_left()
        wbf['header_detail'].set_right()
        wbf['header_detail'].set_top()
        wbf['header_detail'].set_bottom()
        
        return wbf, workbook
