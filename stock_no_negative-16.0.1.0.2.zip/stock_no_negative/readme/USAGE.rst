When you validate a stock operation (a stock move, a picking,
a manufacturing order, etc.) that will set the stock level of a
stockable product as negative, you will be blocked by an error message.
The consumable products can still have a negative stock level.
