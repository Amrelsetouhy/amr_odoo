With an user with full accounting features enabled:

Invoicing --> Accounting --> Actions --> Reconciliation.

From journal items list view you can select check of them and click Action --> Reconcile.

From accounting dashboard you can use reconcile button in Bank / Cash journals.

Also, you can navigate to statements and use the reconcile button.
