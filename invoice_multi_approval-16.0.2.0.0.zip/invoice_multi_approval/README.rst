Invoice multi level approval
============================
* Enables the option for adding multiple approvals to the invoice documents

Installation
============
- www.odoo.com/documentation/16.0/setup/install.html
- Install our custom addon

License
-------
GNU AFFERO GENERAL PUBLIC LICENSE, Version 3 (AGPLv3)
(http://www.gnu.org/licenses/agpl.html)

Company
-------
* `Cybrosys Techno Solutions <https://cybrosys.com/>`__

Credits
-------
* Developer: Sayooj A O
            Version 14 Muhammed Nafih @cybrosys
            Version 15 Akshay CK @cybrosys
            Version 16 Sahla Sherin @cybrosys


Contacts
--------
* Mail Contact : odoo@cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com

Further information
===================
HTML Description: `<static/description/index.html>`__
